/*********************************************************************************************************/
/**
 * inserthtml plugin for CKEditor 4.x (Author: gpickin ; email: gpickin@gmail.com)
 * version:	2.0
 * Released: On 2015-03-10
 * Download: http://www.github.com/gpickin/ckeditor-inserthtml
 *
 *
 * Modified from original: inserthtml plugin for CKEditor 3.x (Author: Lajox ; Email: lajox@19www.com)
 * mod-version:	 1.0
 * mod-Released: On 2009-12-11
 * mod-Download: http://code.google.com/p/lajox
 */
/*********************************************************************************************************/

/**************************************************************************************************************
inserthtml plugin for CKEditor 4.x

 --Insert Html Code Plugin

Plugin Description： CKEditor 4.0+ Insert Html Code Plugin 2.0

***************************************************************************************************************/


/**************Help Begin***************/

1. Upload inserthtml folder to  ckeditor/plugins/

2. Configured in the ckeditor/config.js :
    Add to config.toolbar a value 'inserthtml'
e.g.

config.toolbar =
[
    [ 'Source', '-', 'Bold', 'Italic', 'inserthtml' ]
];


3. Again Configured in the ckeditor/config.js ,
   Expand the extra plugin 'inserthtml' such as:

config.extraPlugins='myplugin1,myplugin2,inserthtml';

4. Language Features Removed due to compatibility issues

/**************Help End***************/
